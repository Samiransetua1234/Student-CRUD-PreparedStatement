package com.jspider.Student_CRUD_with_prepared.service;

import com.jspider.Student_CRUD_with_prepared.dao.StudentDao;
import com.jspider.Student_CRUD_with_prepared.dto.Student;

public class StudentService {
	
	StudentDao dao = new StudentDao();
	
	public Student insertStudentService (Student student) {
		
		if(student.getsId()>=1000&&student.getsId()<=9999) {
			return dao.insertStudent(student);
		}else {
			System.err.println("Please enter Student Id of 4 Digits");
		}
		
		return null;
	}
	
	public Student updateStudentService(Student student) {
		
		
		return dao.updateStudent(student);
	}
	
	public void displayAllStudentsService() {
		
		
		dao.displayAllStudents();
	}
	
	public Student deleteStudentService(Student student) {
		
		
		return dao.deleteStudent(student);
	}
}
